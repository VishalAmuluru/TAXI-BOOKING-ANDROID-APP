Taxi Booking Android App

It is a taxi booking android app just like uber, ola 

Android Studio Used

**SCREENSHOT.** <br> <br>
![alt text](https://3.bp.blogspot.com/-GWFLvrcAD_Q/W3RLuPbKVpI/AAAAAAAACU8/23hGf9Z-Gu8fgwMpPyOQdYlL0lxg_aiUwCLcBGAs/s1600/videotogif_2018.08.15_12.42.46.gif) <br><br>
